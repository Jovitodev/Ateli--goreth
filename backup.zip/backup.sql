--
-- PostgreSQL database dump
--

-- Dumped from database version 15.13 (Debian 15.13-0+deb12u1)
-- Dumped by pg_dump version 15.13 (Debian 15.13-0+deb12u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: db_projeto_atelier; Type: SCHEMA; Schema: -; Owner: joaovictor
--

CREATE SCHEMA db_projeto_atelier;


ALTER SCHEMA db_projeto_atelier OWNER TO joaovictor;

--
-- Name: on_update_current_timestamp_clientes(); Type: FUNCTION; Schema: db_projeto_atelier; Owner: joaovictor
--

CREATE FUNCTION db_projeto_atelier.on_update_current_timestamp_clientes() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
   NEW.updated_at = now();
   RETURN NEW;
END;
$$;


ALTER FUNCTION db_projeto_atelier.on_update_current_timestamp_clientes() OWNER TO joaovictor;

--
-- Name: get_nome_cliente(integer); Type: FUNCTION; Schema: public; Owner: joaovictor
--

CREATE FUNCTION public.get_nome_cliente(id_cliente integer) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
  nome_cliente TEXT;
BEGIN
  SELECT nome INTO nome_cliente FROM clientes WHERE id = id_cliente;
  RETURN nome_cliente;
END;
$$;


ALTER FUNCTION public.get_nome_cliente(id_cliente integer) OWNER TO joaovictor;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cache; Type: TABLE; Schema: public; Owner: joaovictor
--

CREATE TABLE public.cache (
    key character varying(255) NOT NULL,
    value text NOT NULL,
    expiration bigint NOT NULL
);


ALTER TABLE public.cache OWNER TO joaovictor;

--
-- Name: cache_locks; Type: TABLE; Schema: public; Owner: joaovictor
--

CREATE TABLE public.cache_locks (
    key character varying(255) NOT NULL,
    owner character varying(255) NOT NULL,
    expiration bigint NOT NULL
);


ALTER TABLE public.cache_locks OWNER TO joaovictor;

--
-- Name: clientes; Type: TABLE; Schema: public; Owner: joaovictor
--

CREATE TABLE public.clientes (
    id bigint NOT NULL,
    nome character varying(100) NOT NULL,
    cpf character varying(14) NOT NULL,
    idade bigint NOT NULL,
    local character varying(100) DEFAULT NULL::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone,
    fk_cliente bigint
);


ALTER TABLE public.clientes OWNER TO joaovictor;

--
-- Name: clientes_id_seq; Type: SEQUENCE; Schema: public; Owner: joaovictor
--

CREATE SEQUENCE public.clientes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.clientes_id_seq OWNER TO joaovictor;

--
-- Name: clientes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: joaovictor
--

ALTER SEQUENCE public.clientes_id_seq OWNED BY public.clientes.id;


--
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: joaovictor
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.failed_jobs OWNER TO joaovictor;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: joaovictor
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.failed_jobs_id_seq OWNER TO joaovictor;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: joaovictor
--

ALTER SEQUENCE public.failed_jobs_id_seq OWNED BY public.failed_jobs.id;


--
-- Name: job_batches; Type: TABLE; Schema: public; Owner: joaovictor
--

CREATE TABLE public.job_batches (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    total_jobs bigint NOT NULL,
    pending_jobs bigint NOT NULL,
    failed_jobs bigint NOT NULL,
    failed_job_ids text NOT NULL,
    options text,
    cancelled_at bigint,
    created_at bigint NOT NULL,
    finished_at bigint
);


ALTER TABLE public.job_batches OWNER TO joaovictor;

--
-- Name: jobs; Type: TABLE; Schema: public; Owner: joaovictor
--

CREATE TABLE public.jobs (
    id bigint NOT NULL,
    queue character varying(255) NOT NULL,
    payload text NOT NULL,
    attempts smallint NOT NULL,
    reserved_at bigint,
    available_at bigint NOT NULL,
    created_at bigint NOT NULL
);


ALTER TABLE public.jobs OWNER TO joaovictor;

--
-- Name: jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: joaovictor
--

CREATE SEQUENCE public.jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.jobs_id_seq OWNER TO joaovictor;

--
-- Name: jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: joaovictor
--

ALTER SEQUENCE public.jobs_id_seq OWNED BY public.jobs.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: joaovictor
--

CREATE TABLE public.migrations (
    id bigint NOT NULL,
    migration character varying(255) NOT NULL,
    batch bigint NOT NULL
);


ALTER TABLE public.migrations OWNER TO joaovictor;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: joaovictor
--

CREATE SEQUENCE public.migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migrations_id_seq OWNER TO joaovictor;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: joaovictor
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: joaovictor
--

CREATE TABLE public.password_reset_tokens (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp with time zone
);


ALTER TABLE public.password_reset_tokens OWNER TO joaovictor;

--
-- Name: pedidos; Type: TABLE; Schema: public; Owner: joaovictor
--

CREATE TABLE public.pedidos (
    id bigint NOT NULL,
    cliente_id bigint NOT NULL,
    tipo_pedido character varying(255) NOT NULL,
    valor numeric(10,2) NOT NULL,
    status_pagamento character varying(50) NOT NULL,
    status_execucao character varying(50) NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.pedidos OWNER TO joaovictor;

--
-- Name: pedidos_id_seq; Type: SEQUENCE; Schema: public; Owner: joaovictor
--

CREATE SEQUENCE public.pedidos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pedidos_id_seq OWNER TO joaovictor;

--
-- Name: pedidos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: joaovictor
--

ALTER SEQUENCE public.pedidos_id_seq OWNED BY public.pedidos.id;


--
-- Name: sessions; Type: TABLE; Schema: public; Owner: joaovictor
--

CREATE TABLE public.sessions (
    id character varying(255) NOT NULL,
    user_id numeric,
    ip_address character varying(45) DEFAULT NULL::character varying,
    user_agent text,
    payload text NOT NULL,
    last_activity bigint NOT NULL
);


ALTER TABLE public.sessions OWNER TO joaovictor;

--
-- Name: users; Type: TABLE; Schema: public; Owner: joaovictor
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    email_verified_at timestamp with time zone,
    password character varying(255) NOT NULL,
    remember_token character varying(100) DEFAULT NULL::character varying,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


ALTER TABLE public.users OWNER TO joaovictor;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: joaovictor
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO joaovictor;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: joaovictor
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: clientes id; Type: DEFAULT; Schema: public; Owner: joaovictor
--

ALTER TABLE ONLY public.clientes ALTER COLUMN id SET DEFAULT nextval('public.clientes_id_seq'::regclass);


--
-- Name: failed_jobs id; Type: DEFAULT; Schema: public; Owner: joaovictor
--

ALTER TABLE ONLY public.failed_jobs ALTER COLUMN id SET DEFAULT nextval('public.failed_jobs_id_seq'::regclass);


--
-- Name: jobs id; Type: DEFAULT; Schema: public; Owner: joaovictor
--

ALTER TABLE ONLY public.jobs ALTER COLUMN id SET DEFAULT nextval('public.jobs_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: joaovictor
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: pedidos id; Type: DEFAULT; Schema: public; Owner: joaovictor
--

ALTER TABLE ONLY public.pedidos ALTER COLUMN id SET DEFAULT nextval('public.pedidos_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: joaovictor
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: cache; Type: TABLE DATA; Schema: public; Owner: joaovictor
--

COPY public.cache (key, value, expiration) FROM stdin;
\.


--
-- Data for Name: cache_locks; Type: TABLE DATA; Schema: public; Owner: joaovictor
--

COPY public.cache_locks (key, owner, expiration) FROM stdin;
\.


--
-- Data for Name: clientes; Type: TABLE DATA; Schema: public; Owner: joaovictor
--

COPY public.clientes (id, nome, cpf, idade, local, created_at, updated_at, fk_cliente) FROM stdin;
1	João Victor Oliveira	071012663-80	24	Pindaiba	2025-07-07 11:20:41-03	2025-07-07 11:20:41-03	\N
2	Lia Verônica	609.342.340-94	26	Cidade Olímpica	2025-07-07 11:24:51-03	2025-07-07 11:24:51-03	\N
3	Maria Antonieta	533.645.840-60	30	Bequimão - Slz	2025-07-07 11:26:43-03	2025-07-07 11:26:43-03	\N
4	Marcela	248.204.030-28	17	Pará	2025-07-07 11:49:18-03	2025-07-07 11:49:18-03	\N
5	Eduarda	953.858.170-90	28	Caxias	2025-07-07 12:10:49-03	2025-07-07 12:10:49-03	\N
\.


--
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: joaovictor
--

COPY public.failed_jobs (id, uuid, connection, queue, payload, exception, failed_at) FROM stdin;
\.


--
-- Data for Name: job_batches; Type: TABLE DATA; Schema: public; Owner: joaovictor
--

COPY public.job_batches (id, name, total_jobs, pending_jobs, failed_jobs, failed_job_ids, options, cancelled_at, created_at, finished_at) FROM stdin;
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: joaovictor
--

COPY public.jobs (id, queue, payload, attempts, reserved_at, available_at, created_at) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: joaovictor
--

COPY public.migrations (id, migration, batch) FROM stdin;
1	0001_01_01_000000_create_users_table	1
2	0001_01_01_000001_create_cache_table	1
3	0001_01_01_000002_create_jobs_table	1
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: joaovictor
--

COPY public.password_reset_tokens (email, token, created_at) FROM stdin;
\.


--
-- Data for Name: pedidos; Type: TABLE DATA; Schema: public; Owner: joaovictor
--

COPY public.pedidos (id, cliente_id, tipo_pedido, valor, status_pagamento, status_execucao, created_at, updated_at) FROM stdin;
1	1	Costura na calça	30.00	sim	concluído	2025-07-07 13:04:54-03	2025-07-08 19:52:57-03
2	1	Calça nova	300.00	sim	não conluido	2025-07-07 13:09:03-03	2025-07-07 13:09:03-03
3	3	CORTE E COSTURA	60.00	nao	pendente	2025-07-07 13:22:21-03	2025-07-07 13:22:21-03
4	1	SDSDS	20.00	sim	pendente	2025-07-07 13:28:18-03	2025-07-07 13:28:18-03
5	1	rerer	23.00	nao	pendente	2025-07-07 13:39:47-03	2025-07-07 13:39:47-03
6	1	erer	23.00	nao	pendente	2025-07-07 13:41:18-03	2025-07-07 13:41:18-03
7	1	uuuu	434.00	sim	em_andamento	2025-07-07 13:42:35-03	2025-07-07 13:42:35-03
8	4	teste	22.00	nao	em_andamento	2025-07-07 13:57:04-03	2025-07-07 13:57:04-03
9	5	2222	2222.00	nao	nao_concluido	2025-07-07 14:03:42-03	2025-07-07 14:03:42-03
10	5	rerere	555.00	nao	pendente	2025-07-07 14:04:01-03	2025-07-07 14:04:01-03
11	3	2323	2323.00	nao	pendente	2025-07-07 14:30:14-03	2025-07-07 14:30:14-03
12	1	TESTE 4	555.00	não	não concluído	2025-07-07 14:36:18-03	2025-07-08 17:29:30-03
13	3	teste 8	45.00	nao	em_andamento	2025-07-08 17:05:26-03	2025-07-08 17:05:26-03
14	3	teste 9	98.00	não	pendente	2025-07-08 17:05:40-03	2025-07-08 17:29:11-03
15	5	teste 11	87.00	nao	pendente	2025-07-08 17:26:06-03	2025-07-08 17:26:06-03
16	1	teste 15	230.00	sim	nao_concluido	2025-07-08 19:54:24-03	2025-07-08 19:54:24-03
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: joaovictor
--

COPY public.sessions (id, user_id, ip_address, user_agent, payload, last_activity) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: joaovictor
--

COPY public.users (id, name, email, email_verified_at, password, remember_token, created_at, updated_at) FROM stdin;
\.


--
-- Name: clientes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: joaovictor
--

SELECT pg_catalog.setval('public.clientes_id_seq', 5, true);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: joaovictor
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 1, true);


--
-- Name: jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: joaovictor
--

SELECT pg_catalog.setval('public.jobs_id_seq', 1, true);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: joaovictor
--

SELECT pg_catalog.setval('public.migrations_id_seq', 3, true);


--
-- Name: pedidos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: joaovictor
--

SELECT pg_catalog.setval('public.pedidos_id_seq', 16, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: joaovictor
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: cache idx_16398_primary; Type: CONSTRAINT; Schema: public; Owner: joaovictor
--

ALTER TABLE ONLY public.cache
    ADD CONSTRAINT idx_16398_primary PRIMARY KEY (key);


--
-- Name: cache_locks idx_16403_primary; Type: CONSTRAINT; Schema: public; Owner: joaovictor
--

ALTER TABLE ONLY public.cache_locks
    ADD CONSTRAINT idx_16403_primary PRIMARY KEY (key);


--
-- Name: clientes idx_16409_primary; Type: CONSTRAINT; Schema: public; Owner: joaovictor
--

ALTER TABLE ONLY public.clientes
    ADD CONSTRAINT idx_16409_primary PRIMARY KEY (id);


--
-- Name: failed_jobs idx_16416_primary; Type: CONSTRAINT; Schema: public; Owner: joaovictor
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT idx_16416_primary PRIMARY KEY (id);


--
-- Name: jobs idx_16424_primary; Type: CONSTRAINT; Schema: public; Owner: joaovictor
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT idx_16424_primary PRIMARY KEY (id);


--
-- Name: job_batches idx_16430_primary; Type: CONSTRAINT; Schema: public; Owner: joaovictor
--

ALTER TABLE ONLY public.job_batches
    ADD CONSTRAINT idx_16430_primary PRIMARY KEY (id);


--
-- Name: migrations idx_16436_primary; Type: CONSTRAINT; Schema: public; Owner: joaovictor
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT idx_16436_primary PRIMARY KEY (id);


--
-- Name: password_reset_tokens idx_16440_primary; Type: CONSTRAINT; Schema: public; Owner: joaovictor
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT idx_16440_primary PRIMARY KEY (email);


--
-- Name: pedidos idx_16446_primary; Type: CONSTRAINT; Schema: public; Owner: joaovictor
--

ALTER TABLE ONLY public.pedidos
    ADD CONSTRAINT idx_16446_primary PRIMARY KEY (id);


--
-- Name: sessions idx_16450_primary; Type: CONSTRAINT; Schema: public; Owner: joaovictor
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT idx_16450_primary PRIMARY KEY (id);


--
-- Name: users idx_16457_primary; Type: CONSTRAINT; Schema: public; Owner: joaovictor
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT idx_16457_primary PRIMARY KEY (id);


--
-- Name: idx_16409_cpf; Type: INDEX; Schema: public; Owner: joaovictor
--

CREATE UNIQUE INDEX idx_16409_cpf ON public.clientes USING btree (cpf);


--
-- Name: idx_16409_fk_cliente; Type: INDEX; Schema: public; Owner: joaovictor
--

CREATE INDEX idx_16409_fk_cliente ON public.clientes USING btree (fk_cliente);


--
-- Name: idx_16416_failed_jobs_uuid_unique; Type: INDEX; Schema: public; Owner: joaovictor
--

CREATE UNIQUE INDEX idx_16416_failed_jobs_uuid_unique ON public.failed_jobs USING btree (uuid);


--
-- Name: idx_16424_jobs_queue_index; Type: INDEX; Schema: public; Owner: joaovictor
--

CREATE INDEX idx_16424_jobs_queue_index ON public.jobs USING btree (queue);


--
-- Name: idx_16446_fk_cliente; Type: INDEX; Schema: public; Owner: joaovictor
--

CREATE INDEX idx_16446_fk_cliente ON public.pedidos USING btree (cliente_id);


--
-- Name: idx_16450_sessions_last_activity_index; Type: INDEX; Schema: public; Owner: joaovictor
--

CREATE INDEX idx_16450_sessions_last_activity_index ON public.sessions USING btree (last_activity);


--
-- Name: idx_16450_sessions_user_id_index; Type: INDEX; Schema: public; Owner: joaovictor
--

CREATE INDEX idx_16450_sessions_user_id_index ON public.sessions USING btree (user_id);


--
-- Name: idx_16457_users_email_unique; Type: INDEX; Schema: public; Owner: joaovictor
--

CREATE UNIQUE INDEX idx_16457_users_email_unique ON public.users USING btree (email);


--
-- Name: clientes on_update_current_timestamp; Type: TRIGGER; Schema: public; Owner: joaovictor
--

CREATE TRIGGER on_update_current_timestamp BEFORE UPDATE ON public.clientes FOR EACH ROW EXECUTE FUNCTION db_projeto_atelier.on_update_current_timestamp_clientes();


--
-- Name: pedidos fk_cliente; Type: FK CONSTRAINT; Schema: public; Owner: joaovictor
--

ALTER TABLE ONLY public.pedidos
    ADD CONSTRAINT fk_cliente FOREIGN KEY (cliente_id) REFERENCES public.clientes(id) ON UPDATE RESTRICT ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

